Student Information ------------------<Student 1 Information> <Student 2 Information>

How to execute the shell -----------------------
<describe how to execute from the command line>

Important Notes --------------
<Any important notes about your system>

Description of Base Functionality --------------------------------
<describe your IMPLEMENTATION of the following commands: jobs, fg, bg, kill, stop, \�C, \�Z >

Description of Extended Functionality ------------------------------------
<describe your IMPLEMENTATION of the following functionality: I/O, Pipes, Exclusive Access >

List of Plugins Implemented --------------------------(Written by Your Team) <plugin name> <description>
(Written by Others) <plugin name> <group name>